<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obuwie</title>
</head>
<body>
      <header>
        <h1>Obuwie męskie</h1>
    </header>
    <section>
        <h2>Zamówienie</h2>
        
        <a href="index.php">Strona główna</a>
    </section>
    <footer>
        <p>Autor strony: Kuba Wiechowski</p>
    </footer>
</body>
</html>
</body>
</html>