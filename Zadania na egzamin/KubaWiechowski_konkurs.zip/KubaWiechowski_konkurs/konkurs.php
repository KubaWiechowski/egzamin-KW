<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WOLONTARIAT SZKOLNY</title>
</head>
<body>
    
</body>
</html> 
<?php

$nagrody = [
    ['1', 'Puchar', 'Nagroda za I miejsce', '500 PLN'],
    ['2', 'Dyplom', 'Nagroda za II miejsce', '200 PLN'],
    ['3', 'Medal', 'Nagroda za III miejsce', '100 PLN'],
    ['4', 'Kurs online', 'Nagroda za IV miejsce', '150 PLN']
];


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    shuffle($nagrody); 
}
?>
   
    <header>
        <h1>KONKURS - WOLONTARIAT SZKOLNY</h1>
    </header>

   
    <div class="main-content">
        
        <section class="left-block">
            <h3>Konkursowe nagrody</h3>
            <form method="POST">
                <button type="submit">Losuj nowe nagrody</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>Nr</th>
                        <th>Nazwa</th>
                        <th>Opis</th>
                        <th>Wartość</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nagrody as $nagroda): ?>
                        <tr>
                            <td><?php echo $nagroda[0]; ?></td>
                            <td><?php echo $nagroda[1]; ?></td>
                            <td><?php echo $nagroda[2]; ?></td>
                            <td><?php echo $nagroda[3]; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

      
        <section class="right-block">
            <img src="puchar.png" alt="Puchar dla wolontariusza">
            <h4>Polecane linki</h4>
            <ul>
                <li><a href="kwerenda1.png">Kwerenda1</a></li>
                <li><a href="kwerenda2.png">Kwerenda2</a></li>
                <li><a href="kwerenda3.png">Kwerenda3</a></li>
                <li><a href="kwerenda4.png">Kwerenda4</a></li>
            </ul>
        </section>
    </div>

    
    <footer>
        <p>Numer zdającego: 12345</p>
    </footer>
</body>
</html>