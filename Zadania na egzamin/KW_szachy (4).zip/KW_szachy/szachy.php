<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KOŁO SZACHOWE</title> 
   <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>

    <main>
        <section id="left">
            <h4>Polecane linki</h4>
            <ul>
                <li><a href="logo.png" target="_blank">kwerenda1</a></li>
                <li><a href="logo.png" target="_blank">kwerenda2</a></li>
                <li><a href="logo.png" target="_blank">kwerenda3</a></li>
                <li><a href="logo.png" target="_blank">kwerenda4</a></li>
            </ul>
         
        <section id="right">
            <h3>Najlepsi gracze naszego koła</h3>
            <table>
                <tr>
                    <th>Pozycja</th>
                    <th>Pseudonim</th>
                    <th>Tytuł</th>
                    <th>Ranking</th>
                    <th>Klasa</th>
                </tr>
           
        </section>
    </main>

    <footer>
        <p>Stronę wykonał: Kuba Wiechowski 4Ti</p>
    </footer>
</body>
</html>